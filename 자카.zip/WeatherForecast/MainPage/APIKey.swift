//
//  APIKey.swift
//  WeatherForecast
//
//  Created by Jaka on 2024-07-13.
//

import Foundation

class APIKey {
    static let weather = "56ebb6dc52ce32f37202b1dba0329bc7"
}
